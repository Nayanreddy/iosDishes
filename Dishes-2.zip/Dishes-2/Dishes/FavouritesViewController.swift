//
//  FavouritesViewController.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import UIKit
import CoreData

class FavouritesVC: UITableViewController {
    
    var dish: Dish!
    let moc = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
    
    
    @IBOutlet weak var favouritesTV: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func fetchAllFavourites() -> [Favourite]{
        
        let favFetchRequest = NSFetchRequest(entityName: "Favourite")
        var favFetchResults: [Favourite] = []
        
        do {
            favFetchResults = try moc.executeFetchRequest(favFetchRequest) as! [Favourite]
        } catch let error as NSError {
            print(error)
        } catch {
        }
        
        return favFetchResults
        
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fetchAllFavourites().count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = self.favouritesTV.dequeueReusableCellWithIdentifier("cell")! as UITableViewCell
        
        cell.textLabel?.text = fetchAllFavourites()[indexPath.row].dish?.dishName
        
        return cell
        
        
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        performSegueWithIdentifier("favDetails", sender: nil)
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        let tabBarController = segue.destinationViewController as! UITabBarController
        let destinationVC0 = tabBarController.viewControllers?[0] as! PhotosViewController
        let destinationVC1 = tabBarController.viewControllers?[1] as! HowToMakeViewController
        
        let row = self.favouritesTV.indexPathForSelectedRow?.row
        
        destinationVC0.dish = self.fetchAllFavourites()[row!].dish
        
        destinationVC1.dish = self.fetchAllFavourites()[row!].dish
        
        
    }
    
    
}
