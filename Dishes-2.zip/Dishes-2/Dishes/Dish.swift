//
//  Dish.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import Foundation
import CoreData


class Dish: NSManagedObject {

// Insert code here to add functionality to your managed object subclass
    class func addDish(moc: NSManagedObjectContext, dishID: String, dishName: String, dishIngredients: String, dishHowToMake:String, dishType: String, dishImage: String,  state:State ) -> Dish
    {
        
        let dish = NSEntityDescription.insertNewObjectForEntityForName("Dish", inManagedObjectContext: moc) as! Dish
        
        dish.dishID = dishID
        dish.dishName = dishName
        dish.dishIngredients = dishIngredients
        dish.dishHowToMake = dishHowToMake
        dish.dishType = dishType
        dish.dishImage = dishImage
        dish.state = state
        
        return dish
        
    }


}
