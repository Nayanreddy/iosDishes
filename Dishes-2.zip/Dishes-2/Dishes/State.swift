//
//  State.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import Foundation
import CoreData


class State: NSManagedObject {

// Insert code here to add functionality to your managed object subclass
    class func addState(moc: NSManagedObjectContext, stateID: String, name: String) -> State
    {
        
        let state = NSEntityDescription.insertNewObjectForEntityForName("State", inManagedObjectContext: moc) as! State
        
        state.stateID = stateID
        state.stateName = name
        
        return state
        
    }


}
