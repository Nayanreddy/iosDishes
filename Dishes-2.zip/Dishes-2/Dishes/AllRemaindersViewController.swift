//
//  AllRemaindersViewController.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import UIKit
import CoreData

class AllRemaindersViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var remainderTV: UITableView!
    
    let moc = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
    var remaindersList: [Remainder] = []
    
    
    override func viewDidLoad() {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(AllRemaindersViewController.refreshList), name: "AllRemaindersShouldRefresh", object: nil)
    }
    
    
    override func viewWillAppear(animated: Bool) {
        remaindersList = fetchAllRemainders()
        refreshList()
    }
    
    func fetchAllRemainders() -> [Remainder]{
        
        let remainderFetchRequest = NSFetchRequest(entityName: "Remainder")
        var remainderFetchResults: [Remainder] = []
        
        do {
            remainderFetchResults = try moc.executeFetchRequest(remainderFetchRequest) as! [Remainder]
        } catch let error as NSError {
            print(error)
        } catch {
            // Catch any other errors
        }
        
        return remainderFetchResults
        
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return remaindersList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = remainderTV.dequeueReusableCellWithIdentifier("cell")! as UITableViewCell
        
        let remainder = remaindersList[indexPath.row]
        cell.textLabel?.text = remainder.dish?.dishName
        
        if (remainder.isOverdue) { // the current time is later than the to-do item's deadline
            cell.detailTextLabel?.textColor = UIColor.redColor()
        } else {
            cell.detailTextLabel?.textColor = UIColor.blackColor() // we need to reset this because a cell with red subtitle may be returned by dequeueReusableCellWithIdentifier:indexPath:
        }
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "'Due' MMM dd 'at' h:mm a" // example: "Due Jan 01 at 12:00 PM"
        cell.detailTextLabel?.text = dateFormatter.stringFromDate(remainder.deadline!)
        
        return cell
        
        
    }
    
    @IBAction func goToHome(sender: AnyObject) {
        
        self.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    
    func refreshList() {
        
        let todoItems = fetchAllRemainders()
        if (todoItems.count >= 64) {
            self.navigationItem.rightBarButtonItem!.enabled = false // disable 'add' button
        }
        remainderTV.reloadData()
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
