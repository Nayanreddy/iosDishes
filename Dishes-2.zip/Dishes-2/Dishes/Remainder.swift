//
//  Remainder.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import Foundation
import CoreData


class Remainder: NSManagedObject {

// Insert code here to add functionality to your managed object subclass
    var isOverdue: Bool {
        return (NSDate().compare(self.deadline!) == NSComparisonResult.OrderedDescending) // deadline is earlier than current date
    }

}
