//
//  ToDoList.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class TodoList: NSObject{
    
    class var sharedInstance : TodoList {
        struct Static {
            static let instance : TodoList = TodoList()
        }
        return Static.instance
    }
    
    func fetchAllRemainders() -> [Remainder]{
        
        let remainderFetchRequest = NSFetchRequest(entityName: "Remainder")
        var remainderFetchResults: [Remainder] = []
        let moc: NSManagedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
        
        do {
            remainderFetchResults = try moc.executeFetchRequest(remainderFetchRequest) as! [Remainder]
        } catch let error as NSError {
            print(error)
        } catch {
            // Catch any other errors
        }
        
        return remainderFetchResults
        
    }
    
    
    
    func addItem(moc: NSManagedObjectContext, item: Dish, deadline: NSDate){
        
        
        let remaind = NSEntityDescription.insertNewObjectForEntityForName("Remainder", inManagedObjectContext: moc) as! Remainder
        
        remaind.dish = item
        
        let uuid = NSUUID().UUIDString
        remaind.uuid = uuid
        remaind.deadline = deadline
        
        do {
            try moc.save()
        } catch {
            
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        
        // create a corresponding local notification
        let notification = UILocalNotification()
        
        notification.alertBody = "Todo Item \"\(item.dishName!)\" Is Overdue" // text that will be displayed in the notification
        
        notification.alertAction = "open" // text that is displayed after "slide to..." on the lock screen - defaults to "slide to view"
        
        notification.fireDate = deadline // todo item due date (when notification will be fired)
        
        notification.soundName = UILocalNotificationDefaultSoundName // play default sound
        
        
        print("Name111 \(item.dishName)")
        print("uuid111 \(uuid)")
        
        notification.userInfo = ["UUID": uuid, "title": item.dishName!] // assign a unique identifier to the notification so that we can retrieve it later
        
        
        notification.category = "TODO_CATEGORY"
        UIApplication.sharedApplication().scheduleLocalNotification(notification)
        
        self.setBadgeNumbers()
        
        //return remaind
    }
    //
    //    func removeItem(item: TodoItem) {
    //        for notification in UIApplication.sharedApplication().scheduledLocalNotifications as! [UILocalNotification] { // loop through notifications...
    //            if (notification.userInfo!["UUID"] as! String == item.UUID) { // ...and cancel the notification that corresponds to this TodoItem instance (matched by UUID)
    //                UIApplication.sharedApplication().cancelLocalNotification(notification) // there should be a maximum of one match on UUID
    //                break
    //            }
    //        }
    //
    //        if var todoItems = NSUserDefaults.standardUserDefaults().dictionaryForKey(ITEMS_KEY) {
    //            todoItems.removeValueForKey(item.UUID)
    //            NSUserDefaults.standardUserDefaults().setObject(todoItems, forKey: ITEMS_KEY) // save/overwrite todo item list
    //        }
    //    }
    
    
    func setBadgeNumbers() {
        
        let notifications = UIApplication.sharedApplication().scheduledLocalNotifications! as [UILocalNotification] // all scheduled notifications
        
        let todoItems: [Remainder] = self.fetchAllRemainders()
        
        for notification in notifications {
            
            let overdueItems = todoItems.filter({ (todoItem) -> Bool in // array of to-do items...
                return (todoItem.deadline!.compare(notification.fireDate!) != .OrderedDescending) // ...where item deadline is before or on notification fire date
            })
            UIApplication.sharedApplication().cancelLocalNotification(notification) // cancel old notification
            notification.applicationIconBadgeNumber = overdueItems.count // set new badge number
            //UIApplication.sharedApplication().scheduleLocalNotification(notification) // reschedule notification
        }
    }
    
    
    func scheduleReminderforItem(item: Remainder) {
        
        
        let notification = UILocalNotification() // create a new reminder notification
        notification.alertBody = "Reminder: Todo Item \"\(item.dish?.dishName!)\" Is Overdue" // text that will be displayed in the notification
        notification.alertAction = "open" // text that is displayed after "slide to..." on the lock screen - defaults to "slide to view"
        notification.fireDate = NSDate().dateByAddingTimeInterval(30) // 30 minutes from current time
        notification.soundName = UILocalNotificationDefaultSoundName // play default sound
        
        //        print(item.dish?.dishName)
        //        print(item.uuid)
        
        notification.userInfo = ["title": (item.dish?.dishName)!, "UUID": item.uuid!] // assign a unique identifier to the notification that we can use to retrieve it later
        notification.category = "TODO_CATEGORY"
        
        UIApplication.sharedApplication().scheduleLocalNotification(notification)
    }
    
    
    
    
}