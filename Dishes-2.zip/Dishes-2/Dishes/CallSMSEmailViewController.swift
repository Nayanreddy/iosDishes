//
//  CallSMSEmailViewController.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import UIKit
import MessageUI

class CallSMSEmailViewController: UIViewController,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate, UITextFieldDelegate  {
    
    
    @IBOutlet weak var mobileNo: UITextField!
    @IBOutlet weak var emailID: UITextField!
    @IBOutlet weak var smsNo: UITextField!
    
    var dish: Dish!
    
    @IBAction func phoneCall(sender: AnyObject) {
        
        print(mobileNo.text)
        
        if(mobileNo.text! == ""){
            
            let url:NSURL = NSURL(string:"tel://"+String("7576937599"))!
            UIApplication.sharedApplication().openURL(url)
        }
        else{
            
            let url:NSURL = NSURL(string:"tel://"+String(mobileNo.text!))!
            UIApplication.sharedApplication().openURL(url)
        }
    }
    
    
    @IBAction func sendMessage(sender: AnyObject) {
        if (MFMessageComposeViewController.canSendText()) {
            let controller = MFMessageComposeViewController()
            controller.body = "Message Body"
            
            if(smsNo.text! == ""){
                controller.recipients = [String("7576937599")]
            }
            else{
                controller.recipients = [String(smsNo.text!)]
            }
            controller.messageComposeDelegate = self
            self.presentViewController(controller, animated: true, completion: nil)
        }
    }
    
    func messageComposeViewController(controller: MFMessageComposeViewController, didFinishWithResult result: MessageComposeResult) {
        //... handle sms screen actions
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func sendMail(sender: AnyObject) {
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.presentViewController(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self // Extremely important to set the --mailComposeDelegate-- property, NOT the --delegate-- property
        if(emailID.text! == ""){
            mailComposerVC.setToRecipients(["sai28593@gmail.com"])
        }
        else{
            mailComposerVC.setToRecipients([emailID.text!])
        }
        mailComposerVC.setSubject(dish.dishName!)
        mailComposerVC.setMessageBody("Dish Ingredients : \n\n " + dish.dishIngredients! + "\n\n\n How To Make: \n\n" + dish.dishHowToMake!+"\n", isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
        //        let sendMailErrorAlert = UIAlertView(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", delegate: self, cancelButtonTitle: "OK")
        //        sendMailErrorAlert.show()
        
        let alert = UIAlertController(title: "!!! Could Not Send Email !!!", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", preferredStyle: UIAlertControllerStyle.Alert)
        let yesBtn = UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil)
        alert.addAction(yesBtn)
        self.presentViewController(alert, animated: true, completion: nil)
        
        
    }
    
    // MARK: MFMailComposeViewControllerDelegate
    
    
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        controller.dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func Back(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
