//
//  HowToMakeViewController.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import UIKit

class HowToMakeViewController: UIViewController {

    let moc = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
    var dish: Dish!
    
    
    @IBOutlet weak var dishName: UILabel!
    @IBOutlet weak var descr: UITextView!
    @IBOutlet weak var ingredients: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
        descr.layer.cornerRadius = 6
        descr.layer.borderColor = UIColor.purpleColor().CGColor
        descr.layer.borderWidth = 1
        
        
        ingredients.layer.cornerRadius = 6
        ingredients.layer.borderColor = UIColor.purpleColor().CGColor
        ingredients.layer.borderWidth = 1
        
        dishName.text = dish.dishName
        descr.text = dish.dishHowToMake
        ingredients.text = dish.dishIngredients
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Back(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func addToFavourites(sender: AnyObject) {
        
        Favourite.addToFavourite(moc, dish: self.dish)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
