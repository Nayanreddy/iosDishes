//
//  Favourite.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import Foundation
import CoreData


class Favourite: NSManagedObject {

// Insert code here to add functionality to your managed object subclass
    class func addToFavourite(moc: NSManagedObjectContext, dish: Dish ) -> Favourite
    {
        
        let fav = NSEntityDescription.insertNewObjectForEntityForName("Favourite", inManagedObjectContext: moc) as! Favourite
        
        fav.dish = dish
        
        do {
            try moc.save()
        } catch {
            
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        return fav
    }

}
