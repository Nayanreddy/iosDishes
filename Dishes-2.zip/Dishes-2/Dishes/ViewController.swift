//
//  ViewController.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    let moc = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
    
    @IBOutlet weak var countryDD: UIButton!
    @IBOutlet weak var countryTV: UITableView!
    var stateValues: [State] = []
    var selectedState: State!
    
    var dishValues: [Dish] = []
    var selectedDish: Dish!
    
    @IBOutlet weak var vegNvegTV: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        vegNvegTV.hidden = true
        
        //
        //        let notification = UILocalNotification()
        //
        //        notification.alertBody = "Todo Item \")\" Is Overdue" // text that will be displayed in the notification
        //
        //        notification.alertAction = "open" // text that is displayed after "slide to..." on the lock screen - defaults to "slide to view"
        //
        //        let dateComp: NSDateComponents = NSDateComponents()
        //        dateComp.year = 2015
        //     dateComp.month = 12
        //        dateComp.day = 08
        //        dateComp.hour = 16
        //        dateComp.minute = 44
        //        dateComp.second = 45
        //        let calender: NSCalendar = NSCalendar.currentCalendar()
        //        let date = calender.dateFromComponents(dateComp)
        //
        //        notification.fireDate =  date// todo item due date (when notification will be fired)
        //
        //        notification.soundName = UILocalNotificationDefaultSoundName // play default sound
        //
        //       // notification.userInfo = ["UUID": uuid] // assign a unique identifier to the notification so that we can retrieve it later
        //
        //        notification.category = "TODO_CATEGORY"
        //        UIApplication.sharedApplication().scheduleLocalNotification(notification)
        
        // Do any additional setup after loading the view, typically from a nib.
        //
        //        let India =  Country.addCountry(moc, countryID: "IND", name: "India")
        //        let America =  Country.addCountry(moc, countryID: "USA", name: "America")
        //        let China =  Country.addCountry(moc, countryID: "CHI", name: "China")
        //
        let state1 = State.addState(moc, stateID: "AP", name: "Andhra Pradesh")
        let state2 = State.addState(moc, stateID: "KA", name: "Karnataka")
        let state3 = State.addState(moc, stateID: "TN", name: "Tamilnadu")
        let state4 = State.addState(moc, stateID: "KL", name: "Kerala")
        let state5 = State.addState(moc, stateID: "GU", name: "Gujarat")
       //let state6 = State.addState(moc, stateID: "MA" , name: "Maharastra")
        //let state7 = State.addState(moc, stateID: "RJ", name: "Rajasthan")
        //let state8 = State.addState(moc, stateID: "PJ", name: "Punjab")
        //let state9 = State.addState(moc, stateID: "WB", name: "Bengal")
        
        
       Dish.addDish(moc, dishID: "1", dishName: "chicken", dishIngredients : "Chicken/Turkey - 1 lb (cut into pieces) Onion - 1 (sliced) \n Kuskus - 2 tblsp Cashews -" + "Corriander seeds - 1 tblsp Green chilly - 5-7 Cumin seeds - 1 tblsp Coconut - 1/2 cup (grated) \n Yogurt (Curd) - 1/2 cup \n Ginger-Garlic paste- 2 tsp \n Cardomon - 3 " + "Fennel seeds - ¼ tsp Bay leaf - 1 Cloves - 2 Cinnamon sticks - 1 Oil - 2 tblsp Salt - to taste Cilantro - for garnish", dishHowToMake: "1. Soak kuskus in 1 cup warm water for 10 minutes and then grind it with green chillies, coriander seeds, cumin seeds, cashews,cardamom and coconut. Keep it aside.\n 2. Heat oil in a deep pan. Splutter fennel seeds.Add the bay leaf, cloves and cinnamon. \n 3. Add sliced onions and fry them till they are translucent. Next add the ginger-garlic paste and saute till the raw smell vanishes. \n 4. Add the chicken/turkey pieces and saute for 2 minutes. Next add 1 cup water, yogurt and salt to it. Cover and cook till the chicken is almost done. \n 4. At this stage add the ground paste and add the water required. Check for salt and let the kurma simmer for 5 minutes. \n 5. Garnish with cilantro. This goes very well with barotta, aapam and idiyappam.", dishType: "Non-Veg", dishImage:"Chicken Kurma.jpg", state:  state1)
        
        Dish.addDish(moc, dishID: "2", dishName: "Hyderabad Biriyani", dishIngredients:"Basmati Rice - 3 cups  Onion - 1 bigGreen Chilly - 6  Ginger garlic Paste -  1 tsp Salt - as needed \n Fennel Powder - 1/4 tsp  Coconut Milk - 1 cup \n Water - 3 cups  Ghee - 2 tblsp", dishHowToMake: "1. Take a heavy bottomed vessel and add about 2 inches of the prepared gravy. \n 2. Add half of the cooked rice as the next layer. \n 3. Next layer with the remaining gravy and put the remaining cooked rice as the last layer. \n 4. Top this with chopped cilantro, fried onions and roasted cashews.", dishType: "Non-Veg", dishImage:"Hyderabad biryani.jpg",state : state1)
        
        //  Dish.addDish(moc, dishID: "2", dishName: "Rava Coconut Upma", dishIngredients: " ", dishHowToMake: <#T##String#>, dishType: <#T##String#>, dishImage: <#T##String#>, state: <#T##State#>)
        
        
        // copying file
        
        //Dish.addDish(moc, dishID: "1", dishName: "Chicken Kurma", dishIngredients : "Chicken/Turkey - 1 lb (cut into pieces) Onion - 1 (sliced) \n Kuskus - 2 tblsp Cashews -" + "Corriander seeds - 1 tblsp Green chilly - 5-7 Cumin seeds - 1 tblsp Coconut - 1/2 cup (grated) \n Yogurt (Curd) - 1/2 cup \n Ginger-Garlic paste- 2 tsp \n Cardomon - 3 " + "Fennel seeds - ¼ tsp Bay leaf - 1 Cloves - 2 Cinnamon sticks - 1 Oil - 2 tblsp Salt - to taste Cilantro - for garnish", dishHowToMake: "1. Soak kuskus in 1 cup warm water for 10 minutes and then grind it with green chillies, coriander seeds, cumin seeds, cashews,cardamom and coconut. Keep it aside.\n 2. Heat oil in a deep pan. Splutter fennel seeds.Add the bay leaf, cloves and cinnamon. \n 3. Add sliced onions and fry them till they are translucent. Next add the ginger-garlic paste and saute till the raw smell vanishes. \n 4. Add the chicken/turkey pieces and saute for 2 minutes. Next add 1 cup water, yogurt and salt to it. Cover and cook till the chicken is almost done. \n 4. At this stage add the ground paste and add the water required. Check for salt and let the kurma simmer for 5 minutes. \n 5. Garnish with cilantro. This goes very well with barotta, aapam and idiyappam.", dishType: "Non-Veg", dishImage:"Chicken Kurma.jpg", state:  state1)
        
        
        
       Dish.addDish(moc, dishID: "3", dishName: "Veg Biriyani", dishIngredients:"Basmati Rice - 3 cups  Onion - 1 bigGreen Chilly - 6  Ginger garlic Paste -  1 tsp Salt - as needed \n Fennel Powder - 1/4 tsp  Coconut Milk - 1 cup \n Water - 3 cups  Ghee - 2 tblsp", dishHowToMake: "1. Take a heavy bottomed vessel and add about 2 inches of the prepared gravy. \n 2. Add half of the cooked rice as the next layer. \n 3. Next layer with the remaining gravy and put the remaining cooked rice as the last layer. \n 4. Top this with chopped cilantro, fried onions and roasted cashews.", dishType: "Veg", dishImage:"hyderabadi chicken biriyani.jpg",state : state1)
        
        
        
        //  Dish.addDish(moc, dishID: "2", dishName: "Rava Coconut Upma", dishIngredients: " ", dishHowToMake: <#T##String#>, dishType: <#T##String#>, dishImage: <#T##String#>, state: <#T##State#>)
        
        
        
        Dish.addDish(moc, dishID: "4", dishName: "Rava Coconut Upma", dishIngredients: "Rava(semolina) - 1 cup(serves 2) \n musturd seeds - 1/2 tsp \n urad dhal - 1 tsp \n chana dhal - 1 tsp \n red chillies -2 cnt \n curry leaves - a bunch \n Onion - 1 (small) \n green chillies - 2 or 3 cnt \n coconut -  2tblsp(grated) \n Ghee - 2 tsp \n oil - 2 tsp \n Water - 1 1/2 cup", dishHowToMake: "1. Roast the rava with few drops of ghee, till is the color starts changing. \n 2. Cut the onion into small pieces, G.chilli into halvess, and slightly grind the grated coconut(don't use water to grind). \n 3.In a pan put the oil, then the musturd urad and channa dhal. Fry it till it becomes slight brown color. \n 4. Add Red Chillies and curry leaves. \n 5.Then add the onion and Green Chillies and fry it till it's cooked. \n ", dishType: "Veg", dishImage: "Rava Coconut Upma.JPG", state: state2)
        
        
        
        Dish.addDish(moc, dishID: "5", dishName: "Idly", dishIngredients: " Idli rice - 1 3/4 cup \n Black gram - 1/2 cupFennugreek seeds - 1 tsp \n  Salt - 1 tbsp", dishHowToMake: " 1.Soak rice and black gram separately in water for atleast 1 hour. \n Soaking overnight can be done too. \n Add fenugreek seeds to black gram. \n 2.Drain the water and grind the black gram to a silky soft texture. \n 3.Next grind the rice coarsely. Mix it with black gram batter along with salt. \n 4.Now leave the batter to rest and ferment for at least 6 hours till the batter rises to almost double the size ", dishType: "Veg", dishImage:"idli.jpg", state : state3)
        
        
        
        Dish.addDish(moc, dishID: "6", dishName: "Sambar" , dishIngredients: "Rice - 2 cup \n  Split red gram (tur)dal - 1 cup \n Turmeric - 1/4 tsp \n Water- 5 cups \n Tamarind - lemon sized \n   Small onions - 6nos \n            Tomato - 1 big \n Green chillies - 2 nos ( finely chopped ) \n Potato - 1/4 cup ( cut into cubes) \n Eggplant - 1 big/ 3 small( cut into cubes) \n French beans - 1/4 cup (cut into small pieces) \n Drumstick - 1 (cut into small pieces) \n Sambar powder- 3 tsp \n  Oil - 2 tbsp ghee - 2 tbsp \n   Cumin seeds- 1/2 tsp \n Mustard Seeds - 1/2 tsp \n Fenugreek seeds - 1/2 tsp Curry leaves- 10 \n Coriander leaves(Cilantro) - for garnish (finely chopped) \n Asafoetida - 1/4 tsp \n Salt - To taste", dishHowToMake: " 1. Cook rice and split red gram in 5 cups of water. \n 2. Heat oil in a wide skillet.Now add mustard seed. \n Once it pops add fenugreek seend, cumin seeds, asafoetida, curry leaves. Fry \n Saute the onions. Cook tomato, green chillies, potatoes, brinjal, french beans,drumstick in 3/4 cup of water. \n Add the cooked veggies, sambar powder and tamarind water (tamarind soaked in water ) to the rice and cook on medium heat for seven minutes. \n Add ghee and stir well and remove from heat. \n Garnish with cilantro. Serve hot. ", dishType: "Veg", dishImage:"sambar.png",state : state4)
        
        
        
        Dish.addDish(moc, dishID: "7", dishName: "Appam", dishIngredients:"Raw Rice - 2 cups \n •Shredded coconut - handful\n Cooked rice - Handful (You could also use pressed rice/poha/aval instead) \n •Yeast - 1/2 spoon \n •Sugar - 2-3 tsp \n Salt - as needed", dishHowToMake: "1.Soak the rice for 2 hours \n 2.Grind coconut and cooked rice together until smooth. To this add the rice and grind everything together. \n 3.Add the yeast, salt and sugar and mix well. Let it ferment for few hours or \n 4.Make Appam in the appam kal else make it like pancakes on regular griddle. Pour a spoonful of batter and spread using circular motion by holding the handle of the griddle.",dishType: "Veg",
                     
                     dishImage:"appam.jpg", state : state4)
        
        
        
        Dish.addDish(moc, dishID: "8", dishName: "Bhendi Baja", dishIngredients: "Bhindi (Okra) - 1/2 lb (250 gms)," +
            
            "Turmeric powder – 0.5 tsp, Salt - to taste, Mustard Oil - 1 tbsp", dishHowToMake: "• Cut the okra into small pieces." + "\n • In a frying pan, heat the mustard oil." + "\n • Add the okra pieces and mix with the oil.",dishType: "Veg",
                                                                                  
                                                                                  dishImage:"Bhendi Bhaja.jpg", state : state5)
        
        Dish.addDish(moc, dishID: "9", dishName: "Naadan Chicken", dishIngredients:"•Chicken - 1 kg (cut into medium size pieces) \n •Onion - 6 (sliced thinly) \n •Ginger - 2 piece (crushed) \n •Garlic - 1 bulb (crushed) \n •Mustard seeds - 1/2 tsp \n •Fenugreek seeds - 1/8 tsp \n •Red chili Powder - 2 tbsp \n •Coriander Powder - 2 tbsp \n Turmeric Powder - 1/2 tsp \n •Crushed Whole Spices - 1 cinnamon, \n 2 cloves, \n 2 cardamom, \n 1 tsp Fennel seeds, \n 1/2 tsp Peppercorns (or use store bought chicken masala powder) \n •Curry Leaves - 2 sprigs \n •Coconut pieces - 2-3 tbsp \n •Coconut oil - 3 tbsp \n •Salt - as needed ", dishHowToMake: "1.Heat the oil in a heavy bottomed pan and crackle the mustard seeds \n 2.Reduce the heat and add the fenugreek seeds Fry for few seconds. \n 3.Add the ginger, garlic, curry leaves and crushed whole spices. \n 4.Cook for about half a minute  \n 5.Add the sliced onions and saute. \n Add some salt to speed up the process. \n 6.Saute on medium heat for 10-15 minutes till it become golden brown and pasty. \n 7.Add the salt, turmeric powder,coriander powder and chili powder. \n Mix together and fry for few seconds to awaken the aroma of the spices. \n 8.Add the chicken pieces and toss to coat with the spices. \n 9.Cover and let it cook in its own juices for about 5 minutes \n 10.Add required amount of  water. Cover and cook on medium heat for about 10 minutes. \n 11.Switch off and keep covered till you are ready to serve.", dishType: "Non-Veg", dishImage: "Naadan Chicken.jpg", state: state4)
        
        
        
        
        
        Dish.addDish(moc, dishID: "10", dishName: "Khandvi", dishIngredients:"Gram Flour (Besan) - 1 cup \n Yogurt - 1 cupWater - 1 cup \n Turmeric Powder - 1/8 tsp \n Asafoetida - pinch Ginger paste - blueberry size \n GreenChilly paste - 1/4 tsp(optional) \n Grated Coconut - 1 tblsp \n Mustard Seeds - 1 tsp \n Sesame Seeds - 1 tsp \n Dry Red Chilly - 1 \n Oil - 2 tblsp \n Curry Leaves - 1 spring \n Salt - to taste \n Cilantro - forgarnishing(finely chopped)", dishHowToMake: "Mix together the gram flour, ginger paste, green chilly paste, turmeric powder, asafoetida and required salt. \n Add the yogurt and water gradually while stirring continuously to make a smooth paste. \n Transfer this to a pan and cook the mixture for about 10 minutes stirring continuously. \n After the besan mixture is completely cooked and it becomes like a smooth paste, switch off the flame \n Using a spatula take some of the mixture and spread it onto a smooth ungreased surface immediately. \n Let it cool for about 5 minutes \n In the meantime heat a pan and make a seasoning of mustard seeds,sesame seeds,  curry leaves and dry red chilly \n Sprinkle half of the seasoning over the mixture. \n Cut into thin strips and roll up each strip into firm roll \n Arrange the rolls in a serving dish, garnish with the remaining seasoning, finely chopped cilantro and grated coconut", dishType: "Veg", dishImage: "Khandvi.jpg", state: state5)
        // copied
        
        //Dish.addDish(moc, dishID: "2", dishName: "Rava Coconut Upma", dishIngredients: "Rava(semolina) - 1 cup(serves 2) \n musturd seeds - 1/2 tsp \n urad dhal - 1 tsp \n chana dhal - 1 tsp \n red chillies -2 cnt \n curry leaves - a bunch \n Onion - 1 (small) \n green chillies - 2 or 3 cnt \n coconut -  2tblsp(grated) \n Ghee - 2 tsp \n oil - 2 tsp \n Water - 1 1/2 cup", dishHowToMake: "1. Roast the rava with few drops of ghee, till is the color starts changing. \n 2. Cut the onion into small pieces, G.chilli into halvess, and slightly grind the grated coconut(don't use water to grind). \n 3.In a pan put the oil, then the musturd urad and channa dhal. Fry it till it becomes slight brown color. \n 4. Add Red Chillies and curry leaves. \n 5.Then add the onion and Green Chillies and fry it till it's cooked. \n ", dishType: "Veg", dishImage: "Rava Coconut Upma.JPG", state: state2)
        //Dish.addDish(moc, dishID: "1", dishName: "Sambar", dishIngredients : "Chicken/Turkey - 1 lb (cut into pieces) Onion - 1 (sliced) \n Kuskus - 2 tblsp Cashews -" + "Corriander seeds - 1 tblsp Green chilly - 5-7 Cumin seeds - 1 tblsp Coconut - 1/2 cup (grated) \n Yogurt (Curd) - 1/2 cup \n Ginger-Garlic paste- 2 tsp \n Cardomon - 3 " + "Fennel seeds - ¼ tsp Bay leaf - 1 Cloves - 2 Cinnamon sticks - 1 Oil - 2 tblsp Salt - to taste Cilantro - for garnish", dishHowToMake: "1. Soak kuskus in 1 cup warm water for 10 minutes and then grind it with green chillies, coriander seeds, cumin seeds, cashews,cardamom and coconut. Keep it aside.\n 2. Heat oil in a deep pan. Splutter fennel seeds.Add the bay leaf, cloves and cinnamon. \n 3. Add sliced onions and fry them till they are translucent. Next add the ginger-garlic paste and saute till the raw smell vanishes. \n 4. Add the chicken/turkey pieces and saute for 2 minutes. Next add 1 cup water, yogurt and salt to it. Cover and cook till the chicken is almost done. \n 4. At this stage add the ground paste and add the water required. Check for salt and let the kurma simmer for 5 minutes. \n 5. Garnish with cilantro. This goes very well with barotta, aapam and idiyappam.", dishType: "Veg", dishImage:"Chicken Kurma.jpg", state:  state1)
        
        
        
       // Dish.addDish(moc, dishID: "3", dishName: "Hyderabad Biriyani", dishIngredients:"Basmati Rice - 3 cups  Onion - 1 bigGreen Chilly - 6  Ginger garlic Paste -  1 tsp Salt - as needed \n Fennel Powder - 1/4 tsp  Coconut Milk - 1 cup \n Water - 3 cups  Ghee - 2 tblsp", dishHowToMake: "1. Take a heavy bottomed vessel and add about 2 inches of the prepared gravy. \n 2. Add half of the cooked rice as the next layer. \n 3. Next layer with the remaining gravy and put the remaining cooked rice as the last layer. \n 4. Top this with chopped cilantro, fried onions and roasted cashews.", dishType: "Non-Veg", dishImage:"hyderabadi chicken biriyani.jpg",state : state2)
        
        
        
        //  Dish.addDish(moc, dishID: "2", dishName: "Rava Coconut Upma", dishIngredients: " ", dishHowToMake: <#T##String#>, dishType: <#T##String#>, dishImage: <#T##String#>, state: <#T##State#>)
        
        
        
       // Dish.addDish(moc, dishID: "2", dishName: "Rava Coconut Upma", dishIngredients: "Rava(semolina) - 1 cup(serves 2) \n musturd seeds - 1/2 tsp \n urad dhal - 1 tsp \n chana dhal - 1 tsp \n red chillies -2 cnt \n curry leaves - a bunch \n Onion - 1 (small) \n green chillies - 2 or 3 cnt \n coconut -  2tblsp(grated) \n Ghee - 2 tsp \n oil - 2 tsp \n Water - 1 1/2 cup", dishHowToMake: "1. Roast the rava with few drops of ghee, till is the color starts changing. \n 2. Cut the onion into small pieces, G.chilli into halvess, and slightly grind the grated coconut(don't use water to grind). \n 3.In a pan put the oil, then the musturd urad and channa dhal. Fry it till it becomes slight brown color. \n 4. Add Red Chillies and curry leaves. \n 5.Then add the onion and Green Chillies and fry it till it's cooked. \n ", dishType: "Veg", dishImage: "Rava Coconut Upma.png", state: state2)
        
       // Dish.addDish(moc, dishID: "4", dishName: "Idly", dishIngredients: "Idly Ingredients", dishHowToMake: "I dont know how to make Idly", dishType: "Veg", dishImage:"sambar.png", state : state2)
        
        Dish.addDish(moc, dishID: "11", dishName: "Fried Rice", dishIngredients: "Fried Rice Ingredients", dishHowToMake: "I dont know how to make Fried Rice", dishType: "Non-Veg", dishImage:"noodles.png",state : state2)
        
        Dish.addDish(moc, dishID: "12", dishName: "Soup", dishIngredients: "Soup Ingredients", dishHowToMake: "I dont know how to make Soup",dishType: "Veg",
                     dishImage:"pasta.png", state : state3)
        
        
                                                                                
        
        //
        do {
            try moc.save()
        } catch {
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            
        }
        //
        countryTV.layer.masksToBounds = true
        countryTV.layer.borderColor = UIColor( red: 153/255, green: 153/255, blue:153/255, alpha: 1.0 ).CGColor
        countryTV.layer.borderWidth = 1
        
        self.countryTV.hidden = true
        stateValues = fetchAllCountries()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func fetchAllCountries() -> [State]{
        
        let stateFetchRequest = NSFetchRequest(entityName: "State")
        var stateFetchResults: [State] = []
        
        do {
            stateFetchResults = try moc.executeFetchRequest(stateFetchRequest) as! [State]
        } catch let error as NSError {
            print(error)
        } catch {
            // Catch any other errors
        }
        
        //        for country in countryFetchResults{
        //            //print(country.countryName)
        //        }
        //
        
        return stateFetchResults
        
    }
    
    
    func fetchAllDishes() -> [Dish]{
        
        let DishFetchRequest = NSFetchRequest(entityName: "Dish")
        var DishFetchResults: [Dish] = []
        
        do {
            DishFetchResults = try moc.executeFetchRequest(DishFetchRequest) as! [Dish]
        } catch let error as NSError {
            print(error)
        } catch {
            // Catch any other errors
        }
        
        //        for dish in DishFetchResults{
        //           // print(dish.dishName)
        //        }
        
        
        return DishFetchResults
        
    }
    
    
    func fetchAllDishes(country: State, type: String) -> [Dish]{
        
        let DishFetchRequest = NSFetchRequest(entityName: "Dish")
        // var name = country.countryName
        //  DishFetchRequest.predicate = NSPredicate(format: "country contains %@","country")
        var DishFetchResults: [Dish] = []
        var refinedDishResults: [Dish] = []
        
        do {
            DishFetchResults = try moc.executeFetchRequest(DishFetchRequest) as! [Dish]
        } catch let error as NSError {
            print(error)
        } catch {
            // Catch any other errors
        }
        
        for dish in DishFetchResults{
            if(dish.state == country && dish.dishType == type){
                refinedDishResults.append(dish)
            }
            // print(dish.dishName)
        }
        
        
        return refinedDishResults
        
    }
    
    
    func countVegandNonveg(country: State) -> (Int, Int){
        
        dishValues = fetchAllDishes()
        var veg: Int = 0
        var nonveg: Int = 0
        
        for dish in dishValues{
            if dish.state == country{
                if dish.dishType == "Veg"{
                    
                    veg++
                }
                    
                else{
                    nonveg++
                }
                
            }
        }
        
        return (veg, nonveg)
        
    }
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == countryTV{
            return stateValues.count
        }
        else
        {
            return 2
        }
        
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if tableView == countryTV{
            
            let cell = self.countryTV.dequeueReusableCellWithIdentifier("cell")! as UITableViewCell
            
            cell.textLabel?.text = stateValues[indexPath.row].stateName
            
            return cell
        }
        else{
            let cell = self.vegNvegTV.dequeueReusableCellWithIdentifier("row")! as UITableViewCell
            
            if(selectedState != nil){
                
                let countVegNVeg: (Int, Int) = countVegandNonveg(selectedState)
                
                if(indexPath.row == 0){
                    cell.textLabel?.text = "Veg (\(countVegNVeg.0))"
                }
                else{
                    cell.textLabel?.text =  "Non-Veg (\(countVegNVeg.1))"
                }
            }
            else{
                
                
                if(indexPath.row == 0){
                    cell.textLabel?.text = "Veg (0)"
                }
                else{
                    cell.textLabel?.text =  "Non-Veg (0)"
                }
            }
            
            return cell
        }
        
        
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        vegNvegTV.hidden = false
        if tableView == countryTV{
            
            selectedState = stateValues[indexPath.row]
            
            countryDD.setTitle(selectedState.stateName, forState: UIControlState.Normal)
            
            countryTV.hidden = true
            
            self.vegNvegTV.reloadData()
        }
        
        if tableView == vegNvegTV{
            performSegueWithIdentifier("dishes", sender: nil)
        }
        
        
        
    }
    
    
    @IBAction func countryDropDownClick(sender: AnyObject) {
        
        if(self.countryTV.hidden == true){
            self.countryTV.hidden = false
        }
        else{
            self.countryTV.hidden = true
        }
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "dishes"{
            
            let destinationVC = segue.destinationViewController as! DishesListViewController
            let row = self.vegNvegTV.indexPathForSelectedRow?.row
            let countVegNVeg: (Int, Int) = countVegandNonveg(selectedState)
            
            
            if row == 0{
                destinationVC.dishesCount = countVegNVeg.0
                destinationVC.dishes = fetchAllDishes(selectedState, type: "Veg")
            }
            else{
                destinationVC.dishesCount = countVegNVeg.1
                destinationVC.dishes = fetchAllDishes(selectedState,type: "Non-Veg")
            }
            
        }
        
        
        //         print("Dish count is \(countVegNVeg.0)")
        //        print("Dishes are \(destinationVC.dishes.count)")
        
        
    }
    
    
    
    

}

