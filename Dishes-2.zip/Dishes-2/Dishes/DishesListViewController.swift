//
//  DishesListViewController.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import UIKit

class DishesListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var dishesCount: Int!
    var dishes: [Dish] = []
    
    @IBOutlet weak var dishesTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.dishesTV.reloadData()
        //
        //        var customBtn = UIBarButtonItem(title: "Continue", style: .Plain, target: self, action:nil)
        //
        //        self.navigationItem.leftBarButtonItem = customBtn
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dishesCount
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = self.dishesTV.dequeueReusableCellWithIdentifier("dcell")! as UITableViewCell
        
        cell.textLabel?.text = dishes[indexPath.row].dishName
        
        //        print("Final dish count is \(self.dishesCount)")
        //        print("Final Name is \(dishes[indexPath.row].dishName)")
        
        return cell
        
        
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        performSegueWithIdentifier("dishDetails", sender: nil)
    }
    
    
    @IBAction func Back(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        let tabBarController = segue.destinationViewController as! UITabBarController
        let destinationVC0 = tabBarController.viewControllers?[0] as! PhotosViewController
        let destinationVC1 = tabBarController.viewControllers?[1] as! HowToMakeViewController
        let destinationVC2 = tabBarController.viewControllers?[2] as! CallSMSEmailViewController
        
        let row = self.dishesTV.indexPathForSelectedRow?.row
        
        destinationVC0.dish = self.dishes[row!]
        print(self.dishes[row!])
        destinationVC1.dish = self.dishes[row!]
        destinationVC2.dish = self.dishes[row!]
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
   
        