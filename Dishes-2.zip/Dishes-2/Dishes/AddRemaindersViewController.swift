//
//  AddRemaindersViewController.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//

import UIKit
import CoreData

class AddRemaindersViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var dishesDD: UIButton!
    @IBOutlet weak var dishesTV: UITableView!
    
    
    @IBOutlet weak var deadlinePicker: UIDatePicker!
    
    
    var dishValues: [Dish] = []
    var selectedDish: Dish!
    
    let moc = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //dishValues = fetchAllDishes()
        dishesTV.layer.masksToBounds = true
        dishesTV.layer.borderColor = UIColor( red: 153/255, green: 153/255, blue:153/255, alpha: 1.0 ).CGColor
        dishesTV.layer.borderWidth = 1
        
        self.dishesTV.hidden = true
        
    }
    
    override func viewWillAppear(animated: Bool) {
        dishValues = fetchAllDishes()
    }
    
    
    @IBAction func DishesDDBtnClicked(sender: AnyObject) {
        
        if(self.dishesTV.hidden == true){
            self.dishesTV.hidden = false
        }
        else{
            self.dishesTV.hidden = true
        }
        
        
    }
    
    
    @IBAction func addToRemainders(sender: AnyObject) {
        
        TodoList.sharedInstance.addItem(moc, item: selectedDish, deadline: deadlinePicker.date)
        
    }
    
    func fetchAllDishes() -> [Dish]{
        
        let dishFetchRequest = NSFetchRequest(entityName: "Dish")
        var dishFetchResults: [Dish] = []
        
        do {
            dishFetchResults = try moc.executeFetchRequest(dishFetchRequest) as! [Dish]
        } catch let error as NSError {
            print(error)
        } catch {
            // Catch any other errors
        }
        
        return dishFetchResults
        
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = dishesTV.dequeueReusableCellWithIdentifier("cell")! as UITableViewCell
        
        cell.textLabel?.text = dishValues[indexPath.row].dishName
        
        return cell
        
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dishValues.count
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        selectedDish = dishValues[indexPath.row]
        
        dishesDD.setTitle(selectedDish.dishName, forState: UIControlState.Normal)
        
        dishesTV.hidden = true
        
        self.dishesTV.reloadData()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
