//
//  Dish+CoreDataProperties.swift
//  Dishes
//
//  Created by Gaddam,Sushma on 11/14/16.
//  Copyright © 2016 Gaddam,Sushma. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Dish {

    @NSManaged var dishHowToMake: String?
    @NSManaged var dishID: String?
    @NSManaged var dishImage: String?
    @NSManaged var dishIngredients: String?
    @NSManaged var dishName: String?
    @NSManaged var dishType: String?
    @NSManaged var state: State?

}
